package Calisanlar;

public interface ICalisanlar {
     String getName();
     String getDepertmant();
     void Work();
}
