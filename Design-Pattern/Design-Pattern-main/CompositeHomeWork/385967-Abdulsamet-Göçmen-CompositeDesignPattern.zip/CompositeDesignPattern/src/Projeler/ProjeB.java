package Projeler;

public class ProjeB extends Projeler {

    public ProjeB(String projeName) {
        super(projeName);
    }
    
}
