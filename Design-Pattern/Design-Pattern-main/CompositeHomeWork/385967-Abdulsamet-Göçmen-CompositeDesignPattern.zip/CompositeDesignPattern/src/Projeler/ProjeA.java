package Projeler;

public class ProjeA extends Projeler {

    public ProjeA(String projeName) {
        super(projeName);
    }
  

}
